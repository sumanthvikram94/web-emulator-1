# Terms of Use

The Helvetica Neue license includes unlimited usage for all IBM software, either on premise or Software as a Service (SaaS). This license allows you to use the fonts for _"IBM branded software products installed on customer workstations, servers, tablets and mobile devices"_. This includes _"all platforms that support font data installation"_, as well as _"IBM server based software products where the font remains on IBM servers"_ on an unlimited number of servers or CPUs.
