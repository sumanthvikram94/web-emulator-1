
export interface InternalDataSteward{
    
}
export function initWithContext(context: any): any;