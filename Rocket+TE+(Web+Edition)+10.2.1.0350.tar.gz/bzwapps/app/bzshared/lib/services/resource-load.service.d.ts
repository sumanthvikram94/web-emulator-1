
declare function registerResourceLoad(resource);
declare function startChecking();
declare function loadReady();

export {
    registerResourceLoad, startChecking, loadReady
}